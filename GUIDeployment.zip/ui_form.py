# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'form.ui'
##
## Created by: Qt User Interface Compiler version 6.5.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFrame,
    QLabel, QLineEdit, QPlainTextEdit, QProgressBar,
    QPushButton, QSizePolicy, QStackedWidget, QTextBrowser,
    QVBoxLayout, QWidget)

class Ui_Widget(object):
    def setupUi(self, Widget):
        if not Widget.objectName():
            Widget.setObjectName(u"Widget")
        Widget.resize(562, 474)
        Widget.setStyleSheet(u"QWidget {\n"
" background-color: #FFFFFF;\n"
"    color: #000000;\n"
"    text-align: center;\n"
"}")
        self.label = QLabel(Widget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(210, 10, 131, 20))
        self.label.setStyleSheet(u"font: 13pt \"Constantia\";\n"
"	text-align: center;")
        self.reset = QPushButton(Widget)
        self.reset.setObjectName(u"reset")
        self.reset.setGeometry(QRect(180, 180, 151, 20))
        self.reset.setStyleSheet(u"font: 10pt \"Arial\";")
        self.line_2 = QFrame(Widget)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setGeometry(QRect(20, 210, 511, 16))
        self.line_2.setFrameShape(QFrame.HLine)
        self.line_2.setFrameShadow(QFrame.Sunken)
        self.label_5 = QLabel(Widget)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(30, 220, 221, 16))
        self.label_5.setStyleSheet(u"font: 11pt \"Arial\";")
        self.verticalLayoutWidget = QWidget(Widget)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(20, 130, 151, 41))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.label_4 = QLabel(self.verticalLayoutWidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setStyleSheet(u"font: 9pt \"Arial\";")

        self.verticalLayout.addWidget(self.label_4)

        self.lineEdit_3 = QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setStyleSheet(u"QLineEdit{\n"
"font: 9pt \"Courier\";\n"
"    border-style: solid;\n"
"    border-width: 0.5px;\n"
"    border-color: black;\n"
"\n"
"\n"
"\n"
"}\n"
"\n"
"QLineEdit::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}\n"
"\n"
"")

        self.verticalLayout.addWidget(self.lineEdit_3)

        self.verticalLayoutWidget_2 = QWidget(Widget)
        self.verticalLayoutWidget_2.setObjectName(u"verticalLayoutWidget_2")
        self.verticalLayoutWidget_2.setGeometry(QRect(180, 130, 147, 41))
        self.verticalLayout_2 = QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.label_3 = QLabel(self.verticalLayoutWidget_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setStyleSheet(u"font: 9pt \"Arial\";")

        self.verticalLayout_2.addWidget(self.label_3)

        self.lineEdit_2 = QLineEdit(self.verticalLayoutWidget_2)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setStyleSheet(u"QLineEdit{\n"
"font: 9pt \"Courier\";\n"
"    border-style: solid;\n"
"    border-width: 0.5px;\n"
"    border-color: black;\n"
"\n"
"}\n"
"\n"
"QLineEdit::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}")

        self.verticalLayout_2.addWidget(self.lineEdit_2)

        self.verticalLayoutWidget_3 = QWidget(Widget)
        self.verticalLayoutWidget_3.setObjectName(u"verticalLayoutWidget_3")
        self.verticalLayoutWidget_3.setGeometry(QRect(330, 130, 211, 41))
        self.verticalLayout_3 = QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.verticalLayoutWidget_3)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setStyleSheet(u"font: 9pt \"Arial\";")

        self.verticalLayout_3.addWidget(self.label_2)

        self.lineEdit = QLineEdit(self.verticalLayoutWidget_3)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"QLineEdit{\n"
"font: 9pt \"Courier\";\n"
"    border-style: solid;\n"
"    border-width: 0.5px;\n"
"    border-color: black;\n"
"\n"
"}\n"
"\n"
"QLineEdit::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}")

        self.verticalLayout_3.addWidget(self.lineEdit)

        self.label_6 = QLabel(Widget)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(40, 10, 51, 51))
        self.label_6.setPixmap(QPixmap(u"../groundstation/ground_station/assets/iris_logo.png"))
        self.label_6.setScaledContents(True)
        self.stackedWidget = QStackedWidget(Widget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setGeometry(QRect(70, 250, 411, 191))
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.pushButton_3 = QPushButton(self.page_3)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(90, 30, 221, 41))
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
" background-color: #0000ff;\n"
"    color: #FFFFFF;\n"
"    border: none;\n"
"    padding: 10px;\n"
"	font: 12pt \"Arial\";\n"
"    text-align: center;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QPushButton::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}")
        self.stackedWidget.addWidget(self.page_3)
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.progressBar = QProgressBar(self.page)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setGeometry(QRect(10, 30, 381, 23))
        self.progressBar.setValue(24)
        self.pushButton = QPushButton(self.page)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(330, 60, 61, 41))
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #FFFFFF;\n"
"    color: #222831;\n"
"    border: none;\n"
"	background-image: url(\"/Downloads/up-arrow.png\");\n"
"    padding: 10px;\n"
"    font-size: 16px;\n"
"    font-weight: bold;\n"
"    text-align: center;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QPushButton::hover {\n"
"    background-color: #F0EEED;\n"
"    cursor: pointer;\n"
"}\n"
"")
        self.stackedWidget.addWidget(self.page)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.textBrowser = QTextBrowser(self.page_2)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(10, 10, 391, 151))
        self.textBrowser.setStyleSheet(u"font: 10pt \"Courier\";\n"
"borde-style: outset;\n"
"border-width: 2px;\n"
"border-color: black;")
        self.pushButton_2 = QPushButton(self.page_2)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(340, 170, 61, 31))
        self.pushButton_2.setAutoFillBackground(False)
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background-color: #FFFFFF;\n"
"    color: #222831;\n"
"    border: none;\n"
"	border-image: url(\"/Downloads/up-arrow.png\");\n"
"    padding: 10px;\n"
"    font-size: 16px;\n"
"    font-weight: bold;\n"
"    text-align: center;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QPushButton::hover {\n"
"    background-color: #F0EEED;\n"
"    cursor: pointer;\n"
"}\n"
"")
        self.stackedWidget.addWidget(self.page_2)
        self.verticalLayoutWidget_4 = QWidget(Widget)
        self.verticalLayoutWidget_4.setObjectName(u"verticalLayoutWidget_4")
        self.verticalLayoutWidget_4.setGeometry(QRect(20, 80, 151, 41))
        self.verticalLayout_4 = QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.comboBox_3 = QComboBox(self.verticalLayoutWidget_4)
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")
        self.comboBox_3.setStyleSheet(u"QComboBox{\n"
"font: 9pt \"Arial\";\n"
"background-color: #cccccc;\n"
"}\n"
"\n"
"QComboBox::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}\n"
"QComboBox::hover {\n"
"    background-color: #F0EEED;\n"
"    cursor: pointer;\n"
"}\n"
"")

        self.verticalLayout_4.addWidget(self.comboBox_3)

        self.verticalLayoutWidget_5 = QWidget(Widget)
        self.verticalLayoutWidget_5.setObjectName(u"verticalLayoutWidget_5")
        self.verticalLayoutWidget_5.setGeometry(QRect(180, 80, 151, 41))
        self.verticalLayout_5 = QVBoxLayout(self.verticalLayoutWidget_5)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.comboBox_2 = QComboBox(self.verticalLayoutWidget_5)
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setStyleSheet(u"QComboBox{\n"
"font: 9pt \"Arial\";\n"
"background-color: #cccccc;\n"
"}\n"
"\n"
"QComboBox::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}\n"
"\n"
"QComboBox::hover {\n"
"    background-color: #F0EEED;\n"
"    cursor: pointer;\n"
"}")

        self.verticalLayout_5.addWidget(self.comboBox_2)

        self.verticalLayoutWidget_6 = QWidget(Widget)
        self.verticalLayoutWidget_6.setObjectName(u"verticalLayoutWidget_6")
        self.verticalLayoutWidget_6.setGeometry(QRect(340, 80, 151, 41))
        self.verticalLayout_6 = QVBoxLayout(self.verticalLayoutWidget_6)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.comboBox = QComboBox(self.verticalLayoutWidget_6)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setStyleSheet(u"QComboBox{\n"
"font: 9pt \"Arial\";\n"
"background-color: #cccccc;\n"
"}\n"
"\n"
"QComboBox::disabled{\n"
"background-color:grey;\n"
"color:black;\n"
"\n"
"}\n"
"\n"
"QComboBox::hover {\n"
"    background-color: #F0EEED;\n"
"    cursor: pointer;\n"
"}")

        self.verticalLayout_6.addWidget(self.comboBox)

        self.label_7 = QLabel(Widget)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(150, 40, 241, 20))
        self.label_7.setStyleSheet(u"font: 13pt \"Constantia\";")
        self.line = QFrame(Widget)
        self.line.setObjectName(u"line")
        self.line.setGeometry(QRect(20, 60, 511, 20))
        self.line.setFrameShape(QFrame.HLine)
        self.line.setFrameShadow(QFrame.Sunken)
        self.line_3 = QFrame(Widget)
        self.line_3.setObjectName(u"line_3")
        self.line_3.setGeometry(QRect(20, 110, 511, 20))
        self.line_3.setFrameShape(QFrame.HLine)
        self.line_3.setFrameShadow(QFrame.Sunken)
        self.checkBox = QCheckBox(Widget)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setGeometry(QRect(30, 180, 131, 20))
        self.plainTextEdit = QPlainTextEdit(Widget)
        self.plainTextEdit.setObjectName(u"plainTextEdit")
        self.plainTextEdit.setGeometry(QRect(10, 0, 541, 461))
        self.plainTextEdit.setStyleSheet(u"    border-style: ridge;\n"
"    border-width: 1.48px;\n"
"    border-color: black;\n"
" 	border-radius: 25px;\n"
"	padding: 10px;")
        self.plainTextEdit.raise_()
        self.label.raise_()
        self.reset.raise_()
        self.line_2.raise_()
        self.label_5.raise_()
        self.verticalLayoutWidget.raise_()
        self.verticalLayoutWidget_2.raise_()
        self.verticalLayoutWidget_3.raise_()
        self.label_6.raise_()
        self.stackedWidget.raise_()
        self.verticalLayoutWidget_4.raise_()
        self.verticalLayoutWidget_5.raise_()
        self.verticalLayoutWidget_6.raise_()
        self.label_7.raise_()
        self.line.raise_()
        self.line_3.raise_()
        self.checkBox.raise_()

        self.retranslateUi(Widget)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Widget)
    # setupUi

    def retranslateUi(self, Widget):
        Widget.setWindowTitle(QCoreApplication.translate("Widget", u"Widget", None))
        self.label.setText(QCoreApplication.translate("Widget", u"Iris Automation", None))
        self.reset.setText(QCoreApplication.translate("Widget", u"Reset?", None))
        self.label_5.setText(QCoreApplication.translate("Widget", u"Installation Progress", None))
        self.label_4.setText(QCoreApplication.translate("Widget", u"Device Address", None))
        self.lineEdit_3.setText("")
        self.label_3.setText(QCoreApplication.translate("Widget", u"Device Serial Number", None))
        self.label_2.setText(QCoreApplication.translate("Widget", u"Device Comment (optional)", None))
        self.label_6.setText("")
        self.pushButton_3.setText(QCoreApplication.translate("Widget", u"Begin Installation", None))
        self.pushButton.setText(QCoreApplication.translate("Widget", u"^", None))
        self.textBrowser.setHtml(QCoreApplication.translate("Widget", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Courier'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">gggggggggggggggggsdffffffffffffffffffffgfsdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg</span></p>\n"
"<p style=\" margin-top:0px; margin"
                        "-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">g</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">g</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">g</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">g</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">g</span></p></body></html>", None))
        self.pushButton_2.setText(QCoreApplication.translate("Widget", u"^", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("Widget", u"Select Device Type", None))
        self.comboBox_3.setItemText(1, QCoreApplication.translate("Widget", u"Casia G", None))
        self.comboBox_3.setItemText(2, QCoreApplication.translate("Widget", u"Casia GX", None))
        self.comboBox_3.setItemText(3, QCoreApplication.translate("Widget", u"Casia X", None))
        self.comboBox_3.setItemText(4, QCoreApplication.translate("Widget", u"Casia I", None))

        self.comboBox_2.setItemText(0, QCoreApplication.translate("Widget", u"Select FC Version", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("Widget", u"2", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("Widget", u"3", None))

        self.comboBox.setItemText(0, QCoreApplication.translate("Widget", u"Select HSW Version", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Widget", u"2", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("Widget", u"3", None))

        self.label_7.setText(QCoreApplication.translate("Widget", u"Host Software Deployment Tool", None))
        self.checkBox.setText(QCoreApplication.translate("Widget", u"Re-register device?", None))
    # retranslateUi

