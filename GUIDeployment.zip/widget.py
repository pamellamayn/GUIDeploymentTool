from PySide6.QtWidgets import QMainWindow, QApplication, QPushButton, QLineEdit, QComboBox, QVBoxLayout, QLabel, QStackedWidget, QWidget, QCheckBox, QProgressBar
#from PySide6 import uic
import sys
import json
from ui_form import Ui_Widget
from PySide6.QtCore import QRegularExpression, QJsonDocument, QFile, QIODevice
from PySide6.QtGui import QRegularExpressionValidator, QPalette, QColor


class UI(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Widget()
        self.ui.setupUi(self)
        self.setWindowTitle("Deployment Tool")

        #widgets need to be defined first before reading a file
        self.combobox2= self.findChild(QComboBox, "comboBox_2")
        self.combobox= self.findChild(QComboBox, "comboBox")
        self.combobox1= self.findChild(QComboBox, "comboBox_3")


        # Load the JSON file
        #file = QFile("software_versions.json")
        #if file.open(QIODevice.ReadOnly | QIODevice.Text):
            #all_data = json.loads(str(file.readAll(), encoding="utf-8"))
            #file.close()
            #data = [item for item in all_data if item.get('device_model') == 'casia g']
            #v = [item.get('host_sw_version_name') for item in data]
            #data2 = [item for item in all_data if item.get('device_model') == 'casia i']
            #v2 = [item.get('host_sw_version_name') for item in data2]

        self.combobox1.currentIndexChanged.connect(self.pop_second_combobox)
        self.combobox1.currentIndexChanged.connect(self.pop_third_combobox)
        #assign validation
        pattern = QRegularExpression(".*")
        validator1 = QRegularExpressionValidator(pattern)
        self.num_pattern = (QRegularExpression('\b(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\b'))
        #validator3 = QRegularExpressionValidator(self.num_pattern)
        validator2 = QRegularExpressionValidator(QRegularExpression(r'^([a-zA-Z]{1,4})\-([0-9]{1,4})\-([0-9]{1,6})$'))

        # Define our widgets
        #comboBox
        self.combobox= self.findChild(QComboBox, "comboBox")
        self.combobox1= self.findChild(QComboBox, "comboBox_3")
        self.combobox2= self.findChild(QComboBox, "comboBox_2")

        # Vertical layouts with LineEdits+Labels

        # Device Comment (optional)
        self.verticalLayout3= self.findChild(QVBoxLayout, "verticalLayout_3")
        self.comments= self.findChild(QLineEdit, "lineEdit")
        self.comments.setPlaceholderText("Engineering Dev/Test - Office")
        self.comments.setEchoMode(QLineEdit.EchoMode.Normal)
        self.deviceComment= self.findChild(QLabel, "label_2")

        # Device Serial Number
        self.verticalLayout2= self.findChild(QVBoxLayout, "verticalLayout_3")
        self.lineEdit2= self.findChild(QLineEdit, "lineEdit_2")
        self.lineEdit2.setPlaceholderText("GACM-0100-000003")
        self.lineEdit2.setEchoMode(QLineEdit.EchoMode.Normal)
        self.lineEdit2.setValidator(validator2)
        self.serialNum= self.findChild(QLabel, "label_3")

        # Device Address
        self.verticalLayout1= self.findChild(QVBoxLayout, "verticalLayout")
        self.lineEdit3= self.findChild(QLineEdit, "lineEdit_3")
        self.lineEdit3.setPlaceholderText("172.31.100.101")
        self.lineEdit3.setEchoMode(QLineEdit.EchoMode.Normal)
        self.lineEdit3.setValidator(validator1)
        self.lineEdit3.textChanged.connect(self.on_text_changed)
        self.address= self.findChild(QLabel, "label_4")


        # Stacked view
        self.stacked= self.findChild(QStackedWidget, "stackedWidget")
        self.change= self.findChild(QPushButton, "pushButton")
        self.change2= self.findChild(QPushButton, "pushButton_2")
        self.beginInstall= self.findChild(QPushButton, "pushButton_3")
        self.page1= self.findChild(QWidget, "page")
        self.page2= self.findChild(QWidget, "page_2")
        self.page3= self.findChild(QWidget, "page_3")
        self.progress= self.findChild(QProgressBar, "progressBar")

        self.reset= self.findChild(QPushButton, "reset")
        self.checkbox= self.findChild(QCheckBox, "checkBox")

        # widgets need to be hidden first
        self.reset.hide()
        self.combobox2.setEnabled(False)
        self.combobox.setEnabled(False)
        self.comments.setEnabled(False)
        self.lineEdit2.setEnabled(False)
        self.lineEdit3.setEnabled(False)
        self.address.setEnabled(False)
        self.comments.setEnabled(False)
        self.serialNum.setEnabled(False)
        self.beginInstall.setEnabled(False)

        #activate the combobox
        self.combobox1.activated.connect(self.hide_unhide)
        self.combobox2.activated.connect(self.hide_unhide2)
        self.lineEdit3.editingFinished.connect(self.hide_unhide3)
        self.lineEdit2.editingFinished.connect(self.hide_unhide4)
        self.comments.textChanged.connect(self.install)
        self.combobox.activated.connect(self.hide_unhide5)
        self.change.clicked.connect(lambda: self.stacked.setCurrentWidget(self.page2))
        self.change2.clicked.connect(lambda: self.stacked.setCurrentWidget(self.page1))
        self.beginInstall.clicked.connect(lambda: self.stacked.setCurrentWidget(self.page1))

        #self.beginInstall.clicked.connect(self.download)
        self.reset.clicked.connect(self.updateReset)
        # Show The App
        #self.show

        # Keep Track of hidden or not
        #self.hidden = False

    #def download(self):
        #self.completed = 0

        #while self.completed < 100:
            #self.completed += 0.0001
            #self.progress.setValue(self.complete)


    def updateReset(self):
        if self.reset.clicked:
            self.combobox1.setEnabled(True)
            self.combobox1.activated.connect(self.hide_unhide)
            self.combobox2.activated.connect(self.hide_unhide2)
            self.lineEdit3.editingFinished.connect(self.hide_unhide3)
            self.lineEdit2.editingFinished.connect(self.hide_unhide4)
            self.comments.textChanged.connect(self.install)
            self.combobox.activated.connect(self.hide_unhide5)
            self.comments.setEnabled(False)
            self.combobox.setCurrentIndex(0)
            self.combobox1.setCurrentIndex(0)
            self.combobox2.setCurrentIndex(0)
            self.reset.hide()
            self.beginInstall.setEnabled(False)

    def install(self):
        # once device comments is changed the begin install button & reset button is enabled
        if self.comments.textChanged:
            self.beginInstall.setEnabled(True)
            self.reset.show()

        else:
            self.beginInstall.setEnabled(False)

    def hide_unhide(self):
        if self.combobox1.activated:
            self.combobox2.setEnabled(True)
            self.combobox1.setEnabled(False)
        else:
            self.combobox2.setEnabled(False)

    def hide_unhide2(self):
        if self.combobox2.activated:
            self.combobox.setEnabled(True)
            self.combobox2.setEnabled(False)
        else:
            self.combobox.setEnabled(False)

    def hide_unhide3(self):
        if self.lineEdit3.editingFinished:
            self.lineEdit2.setEnabled(True)
            self.serialNum.setEnabled(True)
            self.lineEdit3.setEnabled(False)
        else:
            self.lineEdit2.setEnabled(False)
            self.serialNum.setEnabled(False)

    def hide_unhide4(self):
        if self.lineEdit2.editingFinished:
            self.lineEdit2.setEnabled(True)
            self.comments.setEnabled(True)
            self.lineEdit2.setEnabled(False)
        else:
            self.lineEdit.setEnabled(False)
            self.comments.setEnabled(False)

    def hide_unhide5(self):
        if self.combobox.activated.connect:
            self.lineEdit3.setEnabled(True)
            self.address.setEnabled(True)
            self.combobox.setEnabled(False)
        else:
            self.lineEdit3.setEnabled(False)
            self.address.setEnabled(False)
            #self.hidden = True

    def on_text_changed(self):
        # Get the current text from the line edit
        text = self.lineEdit3.text()
        # Validate the text using the numbers-only validator
        nums_only = self.num_pattern.match(text)
        # If the input is not numbers only, set the background to red
        # Otherwise, set it to white
        if not nums_only:
            self.lineEdit3.setStyleSheet("background-color: red")
        else:
            self.lineEdit3.setStyleSheet("")

    #if device is selected, combobox widget loads versions based on the combobox




    def pop_second_combobox(self, index):

        file = QFile("software_versions.json")
        if file.open(QIODevice.ReadOnly | QIODevice.Text):
            all_data = json.loads(str(file.readAll(), encoding="utf-8"))
            file.close()

            selected_item = self.combobox1.currentText()

            if selected_item == 'Casia G':
                data = [item for item in all_data if item.get('device_model') == 'casia g']
                versions = [item.get('version_name') for item in data]
                self.combobox2.clear()
                self.combobox2.addItems(versions)

            elif selected_item == 'Casia I':
                data = [item for item in all_data if item.get('device_model') == 'casia i']
                versions = [item.get('version_name') for item in data]
                self.combobox2.clear()
                self.combobox2.addItems(versions)

            elif selected_item =='Casia GX':
                data = [item for item in all_data if item.get('device_model') == 'casia gx']
                versions = [item.get('version_name') for item in data]
                self.combobox2.clear()
                self.combobox2.addItems(versions)

            elif selected_item =='Casia X':
                data = [item for item in all_data if item.get('device_model') == 'casia x']
                versions = [item.get('version_name') for item in data]
                self.combobox2.clear()
                self.combobox2.addItems(versions)

            else:
                self.combobox2.clear()

    def pop_third_combobox(self, index):
        file = QFile("software_versions.json")
        if file.open(QIODevice.ReadOnly | QIODevice.Text):
            all_data = json.loads(str(file.readAll(), encoding="utf-8"))
            file.close()

            selected_item = self.combobox2.currentText()

            if selected_item == '3.2.1.115-G':
                data = [item for item in all_data if item.get('version_name') == '3.2.1.115-G']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            elif selected_item == '3.2.0.111-G':
                data = [item for item in all_data if item.get('version_name') == '3.2.0.111-G']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            elif selected_item =='3.1.0.102-G':
                data = [item for item in all_data if item.get('version_name') == '3.1.0.102-G']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            elif selected_item =='3.0.1.98-G':
                data = [item for item in all_data if item.get('device_model') == 'casia x']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            elif selected_item =='Casia X':
                data = [item for item in all_data if item.get('device_model') == 'casia x']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            elif selected_item =='Casia X':
                data = [item for item in all_data if item.get('device_model') == 'casia x']
                versions = [item.get('host_sw_version_name') for item in data]
                self.combobox.clear()
                self.combobox.addItems(versions)

            else:
                self.combobox.clear()

        #data2 = [item for item in all_data if item.get('device_model') == 'casia i']
        #v2 = [item.get('host_sw_version_name') for item in data2]
        #for keys in v2:
            #self.combobox2.addItem(keys)

        #print('casia i:', v2)

        #data3 = [item for item in all_data if item.get('device_model') == 'casia gx']
        #v3 = [item.get('host_sw_version_name') for item in data3]
        #print('casia gx:', v3)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    widget = UI()
    widget.show()
    sys.exit(app.exec())
